# Importing necessary libraries
import pandas as pd
import streamlit as st 
from pycaret.anomaly import * 

# Set page title and load model
st.set_page_config(page_title="Wholesale Anomaly Prediction App")
def get_model():
 return load_model('anomaly')

def predict(model,df):
 predictions = predict_model(model, data = df) 
 return predictions['Anomaly'][0]

model = get_model()

# Set title and description of app
st.title("Wholesale Anomaly Prediction App")
st.markdown("ใส่ข้อมูลการเงินของแต่ละแผนกเพื่อทดสอบว่าเป็นข้อมูลที่ผิดปกติหรือไม่")

# unseen_data = pd.DataFrame({
#     "Channel": ["Retail", "Horeca"],
#     "Region": ["Other", "Other"],
#     "Fresh": [50000, 2000],
#     "Milk": [50000, 2000],
#     "Grocery": [50000, 2000],
#     "Frozen": [50000, 2000],
#     "Detergents_Paper": [50000, 2000],
#     "Delicassen": [50000, 2000]
# })


# Creating the form
form=st.form("anomaly")
Fresh=form.number_input('Fresh',min_value=1,max_value=100000,value=10000)
Milk=form.number_input('Milk',min_value=1,max_value=100000,value=10000)
Grocery=form.number_input('Grocery',min_value=1,max_value=100000,value=10000)
Frozen=form.number_input('Frozen',min_value=1,max_value=100000,value=10000)
Detergents_Paper=form.number_input('Detergents_Paper',min_value=1,max_value=100000,value=10000)
Delicassen=form.number_input('Delicassen',min_value=1,max_value=100000,value=10000)
Channel=form.radio('Channel',['Retail','Horeca'])
Region=form.radio('Region',['Lisbon','Oporto', 'Other'])
predict_button=form.form_submit_button('Predict')

input_dict={'Fresh':Fresh,'Milk':Milk,'Grocery':Grocery,'Frozen':Frozen, 'Detergents_Paper' : Detergents_Paper, 'Delicassen' : Delicassen, 'Channel':Channel, 'Region':Region } 
input_df=pd.DataFrame([input_dict])
if predict_button:
 out = predict(model, input_df)
 st.success('The anamoly prediction = {:b}'.format(out))